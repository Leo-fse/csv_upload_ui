"use client"

import * as React from "react"
import { Download } from "lucide-react"
import { themes } from "@/lib/themes"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DataTable } from "./data-table"
import { Sidebar } from "./sidebar"
import { Header } from "./header"

// サンプルデータ
const tables = {
  users: {
    columns: [
      { accessorKey: "id", header: "ID" },
      { accessorKey: "name", header: "名前" },
      { accessorKey: "email", header: "メール" },
      { accessorKey: "role", header: "役割" },
    ],
    data: [
      { id: 1, name: "山田太郎", email: "taro@example.com", role: "管理者" },
      { id: 2, name: "鈴木花子", email: "hanako@example.com", role: "ユーザー" },
    ],
  },
  orders: {
    columns: [
      { accessorKey: "id", header: "注文ID" },
      { accessorKey: "customer", header: "顧客名" },
      { accessorKey: "amount", header: "金額" },
      { accessorKey: "status", header: "状態" },
    ],
    data: [
      { id: 1, customer: "山田太郎", amount: "¥10,000", status: "完了" },
      { id: 2, customer: "鈴木花子", amount: "¥5,000", status: "処理中" },
    ],
  },
}

export function DataViewer() {
  const [selectedCategory, setSelectedCategory] = React.useState("all")
  const [selectedTable, setSelectedTable] = React.useState("users")
  const theme = themes.light

  const handleDownload = () => {
    const data = tables[selectedTable as keyof typeof tables].data
    const csv = convertToCSV(data)
    downloadCSV(csv, `${selectedTable}.csv`)
  }

  return (
    <div className={`flex h-full flex-col ${theme.primary.background}`}>
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar selectedCategory={selectedCategory} onCategorySelect={setSelectedCategory} />
        <div className="flex-1 overflow-auto">
          <div className="p-8">
            <div className="mb-8 flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-900">データベースビューアー</h1>
              <Button onClick={handleDownload} className="shadow-sm">
                <Download className="mr-2 h-4 w-4" />
                CSVダウンロード
              </Button>
            </div>
            <Tabs value={selectedTable} onValueChange={setSelectedTable} className="space-y-4">
              <TabsList className="bg-gray-100/80 p-1">
                <TabsTrigger value="users" className="rounded-md px-4 py-2 text-sm font-medium transition-colors">
                  ユーザー
                </TabsTrigger>
                <TabsTrigger value="orders" className="rounded-md px-4 py-2 text-sm font-medium transition-colors">
                  注文
                </TabsTrigger>
              </TabsList>
              <TabsContent value="users" className="mt-6">
                <DataTable columns={tables.users.columns} data={tables.users.data} />
              </TabsContent>
              <TabsContent value="orders" className="mt-6">
                <DataTable columns={tables.orders.columns} data={tables.orders.data} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}

// CSVへの変換ユーティリティ
function convertToCSV(data: any[]) {
  if (data.length === 0) return ""

  const headers = Object.keys(data[0])
  const rows = data.map((obj) => headers.map((header) => obj[header]))

  return [headers.join(","), ...rows.map((row) => row.join(","))].join("\n")
}

// CSVダウンロードユーティリティ
function downloadCSV(csv: string, filename: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  link.href = URL.createObjectURL(blob)
  link.setAttribute("download", filename)
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

