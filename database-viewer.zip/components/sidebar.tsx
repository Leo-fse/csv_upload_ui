import { FolderOpen, Users, ShoppingCart, Building } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { themes } from "@/lib/themes"

interface SidebarProps {
  selectedCategory: string
  onCategorySelect: (category: string) => void
}

const categories = [
  { id: "all", name: "すべて", icon: FolderOpen },
  { id: "users", name: "ユーザー", icon: Users },
  { id: "orders", name: "注文", icon: ShoppingCart },
  { id: "companies", name: "企業", icon: Building },
]

export function Sidebar({ selectedCategory, onCategorySelect }: SidebarProps) {
  const theme = themes.light

  return (
    <div className={`w-64 border-r ${theme.sidebar.background} ${theme.sidebar.border} p-6 overflow-y-auto`}>
      <h2 className="mb-6 text-lg font-semibold text-gray-900">カテゴリー</h2>
      <nav className="space-y-1">
        {categories.map((category) => {
          const Icon = category.icon
          return (
            <Button
              key={category.id}
              variant="ghost"
              className={cn(
                "w-full justify-start py-2.5 text-sm font-medium",
                selectedCategory === category.id
                  ? `${theme.sidebar.activeBackground} text-primary`
                  : `${theme.sidebar.text} ${theme.sidebar.hoverBackground}`,
              )}
              onClick={() => onCategorySelect(category.id)}
            >
              <Icon className="mr-3 h-4 w-4" />
              {category.name}
            </Button>
          )
        })}
      </nav>
    </div>
  )
}

