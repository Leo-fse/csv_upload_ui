import type { Metadata } from "next"
import { DataViewer } from "@/components/data-viewer"

export const metadata: Metadata = {
  title: "データベースビューアー",
  description: "データベーステーブルの閲覧とデータのダウンロード",
}

export default function Page() {
  return (
    <div className="h-screen">
      <DataViewer />
    </div>
  )
}

