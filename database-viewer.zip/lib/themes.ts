export const themes = {
  light: {
    primary: {
      background: "bg-white",
      text: "text-gray-900",
      border: "border-gray-200",
    },
    sidebar: {
      background: "bg-gray-50",
      hoverBackground: "hover:bg-gray-100",
      activeBackground: "bg-gray-100",
      text: "text-gray-700",
      border: "border-gray-200",
    },
    header: {
      background: "bg-white",
      text: "text-gray-700",
      border: "border-gray-200",
    },
    table: {
      header: "bg-gray-50",
      row: "hover:bg-gray-50",
      border: "border-gray-200",
    },
    tab: {
      active: "bg-white text-primary border-primary",
      inactive: "text-gray-500 hover:text-gray-700",
    },
  },
}

